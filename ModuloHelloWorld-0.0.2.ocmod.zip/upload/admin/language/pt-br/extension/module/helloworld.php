<?php
// Heading
$_['heading_title']     = 'Conteúdo Hello World';
// Text
$_['text_extension']    = 'Extensões';
$_['text_success']      = 'Sucesso: você modificou o módulo de conteúdo Hello World!';
$_['text_edit']         = 'Editar Módulo de Conteúdo Hello World';
// Entry
$_['entry_name']        = 'Nome do módulo';
$_['entry_title']       = 'Heading Title';
$_['entry_status']      = 'Status';
// Error
$_['error_permission']  = 'Aviso: você não tem permissão para modificar o módulo de conteúdo Hello World!';
$_['error_name']        = 'O nome do módulo deve ter entre 3 e 64 caracteres!';
