<?php
$_['helloworld'] = array(
    'text'        => 'Helloworld',
    'description' => '<h4>Helloworld</h4><p>Dados de demonstração Helloworld.</p>',
    'sql'         => 'helloworld.sql'
);


